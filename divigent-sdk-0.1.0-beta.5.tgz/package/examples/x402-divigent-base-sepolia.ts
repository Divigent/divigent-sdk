/**
 * Wallet-first Divigent + x402 payer demo on Base Sepolia.
 *
 * This is a real x402 flow, not a mocked 402 response:
 *   1. Create one payer wallet from PRIVATE_KEY.
 *   2. Register that wallet on an x402 v2 client for Base Sepolia.
 *   3. Start a local x402 merchant endpoint that charges Divigent's Base
 *      Sepolia USDC token.
 *   4. Attach Divigent to the x402 client.
 *   5. Deposit idle USDC into Divigent.
 *   6. Fetch the paid endpoint. Divigent recalls USDC before x402 signs if
 *      the payer wallet is short.
 *   7. After successful x402 settlement, Divigent deposits any wallet USDC
 *      above the idle buffer back into yield.
 *
 * Why the local merchant? Public Base Sepolia x402 demo endpoints usually
 * charge canonical test USDC at 0x036C..., while this Divigent deployment
 * manages USDC at 0xba50.... Divigent only recalls for payment requirements
 * whose asset matches its own USDC address.
 *
 * The demo endpoint uses x402 v2 + exact + Permit2 because the Divigent test
 * USDC behaves like a permit ERC-20, not an EIP-3009 token.
 *
 * Run:
 *   BASE_SEPOLIA_RPC_URL="https://sepolia.base.org" \
 *   PRIVATE_KEY="0x..." \
 *   PAY_TO_ADDRESS="0xMerchantOrSecondWallet" \
 *   npx tsx examples/x402-divigent-base-sepolia.ts
 *
 * Optional:
 *   X402_PAYMENT_USDC="0.001" \
 *   DIVIGENT_DEPOSIT_USDC="10" \
 *   DIVIGENT_PREFUND_WITHDRAW_USDC="0" \
 *   DIVIGENT_MIN_IDLE_USDC="0.25" \
 *   DIVIGENT_WAIT_FOR_IDLE_DEPOSIT="true" \
 *   X402_FACILITATOR_URL="https://x402.org/facilitator" \
 *   X402_DEMO_PORT="0"
 */
import type { Server } from 'node:http';
import express, { type Express } from 'express';
import {
  Divigent,
  evmAddress,
  formatUsdc,
  parseUsdc,
  usdcAbi,
  type EvmAddress,
} from '@divigent/sdk';
import { HTTPFacilitatorClient } from '@x402/core/server';
import { x402Client, x402HTTPClient } from '@x402/core/client';
import {
  ExactEvmScheme as ExactEvmClient,
  PERMIT2_ADDRESS,
  toClientEvmSigner,
} from '@x402/evm';
import { ExactEvmScheme as ExactEvmServer } from '@x402/evm/exact/server';
import { paymentMiddleware, x402ResourceServer } from '@x402/express';
import { decodePaymentResponseHeader, wrapFetchWithPayment } from '@x402/fetch';
import {
  createPublicClient,
  createWalletClient,
  http,
  type PublicClient,
  type WalletClient,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { baseSepolia } from 'viem/chains';

const X402_NETWORK = 'eip155:84532';
const DEFAULT_RPC_URL = 'https://sepolia.base.org';
const DEFAULT_FACILITATOR_URL = 'https://x402.org/facilitator';
const PAID_PATH = '/paid';
const ALLOWANCE_TIMEOUT_MS = 30_000;
const ALLOWANCE_POLL_MS = 1_000;
const BALANCE_TIMEOUT_MS = 30_000;
const BALANCE_POLL_MS = 1_000;

const rpcUrl = process.env.BASE_SEPOLIA_RPC_URL ?? DEFAULT_RPC_URL;
const privateKey = process.env.PRIVATE_KEY as `0x${string}` | undefined;
const payToInput = process.env.PAY_TO_ADDRESS;
const facilitatorUrl = process.env.X402_FACILITATOR_URL ?? DEFAULT_FACILITATOR_URL;
const requestedPort = Number(process.env.X402_DEMO_PORT ?? '0');
const paymentAmount = envUsdc('X402_PAYMENT_USDC', '0.001');
const depositAmount = envUsdc('DIVIGENT_DEPOSIT_USDC', '10');
const prefundWithdrawAmount = envUsdc('DIVIGENT_PREFUND_WITHDRAW_USDC', '0');
const minIdleThreshold = envUsdc('DIVIGENT_MIN_IDLE_USDC', '0.25');
const waitForIdleDeposit = envFlag('DIVIGENT_WAIT_FOR_IDLE_DEPOSIT', true);

if (privateKey === undefined) {
  throw new Error('Set PRIVATE_KEY to a funded Base Sepolia payer wallet private key');
}
if (payToInput === undefined) {
  throw new Error('Set PAY_TO_ADDRESS to the merchant or second wallet that should receive x402 USDC');
}
if (!Number.isInteger(requestedPort) || requestedPort < 0 || requestedPort > 65535) {
  throw new Error('X402_DEMO_PORT must be an integer between 0 and 65535');
}

const account = privateKeyToAccount(privateKey);
const wallet = evmAddress(account.address);
const payTo = evmAddress(payToInput);

const publicClient = createPublicClient({
  chain: baseSepolia,
  transport: http(rpcUrl),
});

const walletClient = createWalletClient({
  account,
  chain: baseSepolia,
  transport: http(rpcUrl),
});

const divigent = Divigent.create({
  // These casts avoid viem minor-version type noise in apps with multiple
  // web3 packages. They do not change runtime behavior.
  publicClient: publicClient as PublicClient,
  walletClient: walletClient as WalletClient,
  chain: 'base-sepolia',
});

const x402Asset = divigent.addresses.usdc;

// ---------------------------------------------------------------------------
// 1. Wallet-first x402 client
// ---------------------------------------------------------------------------

const payerX402Client = new x402Client()
  .register(
    X402_NETWORK,
    new ExactEvmClient(toClientEvmSigner(account, publicClient), {
      84532: { rpcUrl },
    }),
  )
  .registerPolicy((_version, requirements) => (
    requirements.filter((req) => {
      if (req.scheme !== 'exact') return false;
      if (req.network !== X402_NETWORK) return false;
      if (req.asset.toLowerCase() !== x402Asset.toLowerCase()) return false;
      if (req.payTo.toLowerCase() !== payTo.toLowerCase()) return false;
      try {
        return BigInt(req.amount) <= paymentAmount;
      } catch {
        return false;
      }
    })
  ));

const payerX402Http = new x402HTTPClient(payerX402Client);
const fetchWithPayment = wrapFetchWithPayment(fetch, payerX402Http);
let lastIdleDepositFloor: bigint | undefined;

// ---------------------------------------------------------------------------
// 2. Local x402 merchant endpoint using Divigent USDC
// ---------------------------------------------------------------------------

const merchant = await startLocalMerchantEndpoint({
  asset: x402Asset,
  amount: paymentAmount,
  facilitatorUrl,
  payTo,
  port: requestedPort,
});

// ---------------------------------------------------------------------------
// 3. Attach Divigent to the x402 client
// ---------------------------------------------------------------------------

const divigentHandle = divigent.attachTo(payerX402Client, {
  maxPaymentAmount: paymentAmount,
  minIdleThreshold,
  allowedPayTo: [payTo],
  allowedOrigins: [new URL(merchant.paidUrl).origin],
  allowedResources: [merchant.paidUrl],

  onBeforePayment: (ctx) => {
    console.log('Before x402 payment:');
    console.log(`  payment amount: ${formatUsdc(ctx.paymentAmount)} USDC`);
    console.log(`  wallet balance: ${formatUsdc(ctx.walletBalance)} USDC`);
    console.log(`  reserve floor:  ${formatUsdc(ctx.reserveFloor)} USDC`);
    console.log(`  deficit:        ${formatUsdc(ctx.deficit)} USDC`);

    if (ctx.recallError !== undefined) {
      console.log(`  Divigent recall failed: ${String(ctx.recallError)}`);
    } else if (ctx.recallShares !== undefined) {
      console.log(`  Divigent withdrew ${ctx.recallShares} dvUSDC shares`);
      console.log(`  withdraw tx: ${ctx.recallTxHash}`);
    } else {
      console.log('  no withdrawal needed; wallet already had enough USDC');
    }
  },
  onAfterPaymentCreation: (ctx) => {
    console.log(`x402 payment payload signed for ${formatUsdc(ctx.paymentAmount)} USDC`);
  },
  onPaymentFailure: (ctx) => {
    console.log('x402 payment creation failed');
    console.log(`  recalled USDC first: ${ctx.recalledUsdc ? 'yes' : 'no'}`);
    console.log(`  error: ${String(ctx.error)}`);
  },
  onNonFatalError: (ctx) => {
    console.warn(`Non-fatal Divigent x402 ${ctx.phase} issue: ${ctx.error.message}`);
  },
});

const fetchWithPaymentAndYield = divigentHandle.wrapFetchWithYield(
  fetchWithPayment,
  payerX402Http,
  {
    waitForIdleDeposit,
    onIdleDeposit: (ctx) => {
      console.log('Divigent auto-deposited idle USDC after x402 settlement:');
      console.log(`  deposited: ${formatUsdc(ctx.idleAmount)} USDC`);
      console.log(`  reserve floor kept liquid: ${formatUsdc(ctx.reserveFloor)} USDC`);
      if (ctx.settlementReserve !== undefined) {
        console.log(`  x402 settlement reserve: ${formatUsdc(ctx.settlementReserve)} USDC`);
      }
      console.log(`  tx: ${ctx.txHash}`);
      lastIdleDepositFloor = ctx.reserveFloor;
    },
  },
);

try {
  console.log(`Payer wallet: ${wallet}`);
  console.log(`Merchant payTo: ${payTo}`);
  console.log(`Divigent USDC used for x402: ${x402Asset}`);
  console.log(`Local paid endpoint: ${merchant.paidUrl}`);

  await ensurePermit2Allowance(paymentAmount);
  await depositIntoDivigent(depositAmount);
  await withdrawFromDivigentForAutoDepositTest(prefundWithdrawAmount);

  const response = await fetchWithPaymentAndYield(merchant.paidUrl, {
    headers: {
      accept: 'application/json',
    },
  });

  const body = await response.text();
  console.log(`Paid request status: ${response.status}`);
  logSettlementHeader(response);
  await waitForFinalIdleSweepState();
  await logPostPaymentState();
  console.log(body);
} finally {
  divigentHandle.detach();
  await merchant.close();
}

function envUsdc(name: string, fallback: string): bigint {
  return parseUsdc(process.env[name] ?? fallback);
}

function envFlag(name: string, fallback: boolean): boolean {
  const raw = process.env[name];
  if (raw === undefined) return fallback;
  return ['1', 'true', 'yes', 'on'].includes(raw.toLowerCase());
}

async function waitForHash(hash: `0x${string}`): Promise<void> {
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  if (receipt.status !== 'success') {
    throw new Error(`Transaction failed: ${hash}`);
  }
}

async function ensurePermit2Allowance(amount: bigint): Promise<void> {
  const allowance = await publicClient.readContract({
    address: x402Asset,
    abi: usdcAbi,
    functionName: 'allowance',
    args: [wallet, PERMIT2_ADDRESS],
  });
  if (allowance >= amount) {
    console.log(`Permit2 allowance already covers ${formatUsdc(amount)} USDC`);
    return;
  }

  const { request } = await publicClient.simulateContract({
    address: x402Asset,
    abi: usdcAbi,
    functionName: 'approve',
    args: [PERMIT2_ADDRESS, amount],
    account,
  });
  const hash = await walletClient.writeContract(request);
  await waitForHash(hash);
  await waitForUsdcAllowanceAtLeast(PERMIT2_ADDRESS, amount);
  console.log(`Approved Permit2 for ${formatUsdc(amount)} USDC`);
}

async function depositIntoDivigent(amount: bigint): Promise<void> {
  if (amount === 0n) {
    console.log('Skipping Divigent deposit because DIVIGENT_DEPOSIT_USDC=0');
    return;
  }

  const minDeposit = await divigent.minDeposit();
  if (amount < minDeposit) {
    throw new Error(
      `DIVIGENT_DEPOSIT_USDC=${formatUsdc(amount)} is below the router minimum deposit of ${formatUsdc(minDeposit)} USDC`,
    );
  }

  if (!(await divigent.isAuthorized(wallet))) {
    await waitForHash(await divigent.initialize());
  }

  const walletBalance = await divigent.usdcBalance(wallet);
  if (walletBalance < amount) {
    throw new Error(
      `Wallet has ${formatUsdc(walletBalance)} Divigent USDC, but DIVIGENT_DEPOSIT_USDC=${formatUsdc(amount)}`,
    );
  }

  const routerAllowance = await divigent.usdcAllowance(wallet);
  if (routerAllowance < amount) {
    await waitForHash(await divigent.approveUsdc(amount));
    await waitForUsdcAllowanceAtLeast(divigent.addresses.router, amount);
  }

  const result = await divigent.depositAndWait({
    amount,
    slippageBps: 25,
  });

  console.log(`Deposited ${formatUsdc(amount)} USDC into Divigent`);
  console.log(`Minted ${result.sharesMinted} dvUSDC shares`);
  await waitForUsdcBalanceAtMost(walletBalance - amount);
}

async function withdrawFromDivigentForAutoDepositTest(amount: bigint): Promise<void> {
  if (amount === 0n) return;

  const [walletBalanceBefore, dvUsdcBalance] = await Promise.all([
    divigent.usdcBalance(wallet),
    divigent.dvUsdcBalance(wallet),
  ]);
  if (dvUsdcBalance === 0n) {
    throw new Error('Cannot prefund wallet from Divigent because this wallet has no dvUSDC shares');
  }

  const shares = await divigent.previewWithdrawNet(amount, wallet);
  if (shares === 0n) {
    throw new Error(
      `DIVIGENT_PREFUND_WITHDRAW_USDC=${formatUsdc(amount)} previews to zero dvUSDC shares`,
    );
  }
  if (shares > dvUsdcBalance) {
    throw new Error(
      `DIVIGENT_PREFUND_WITHDRAW_USDC=${formatUsdc(amount)} requires ${shares} dvUSDC shares, but wallet has ${dvUsdcBalance}`,
    );
  }

  const result = await divigent.withdrawAndWait({
    shares,
    wallet,
    slippageBps: 50,
  });

  console.log('Pre-payment Divigent withdrawal for auto-deposit test:');
  console.log(`  requested: ${formatUsdc(amount)} USDC`);
  console.log(`  burned: ${shares} dvUSDC shares`);
  console.log(`  returned: ${formatUsdc(result.usdcReturned)} USDC`);
  console.log(`  tx: ${result.txHash}`);
  await waitForUsdcBalanceAtLeast(walletBalanceBefore + result.usdcReturned);
}

async function logPostPaymentState(): Promise<void> {
  const [walletBalance, dvUsdcBalance] = await Promise.all([
    divigent.usdcBalance(wallet),
    divigent.dvUsdcBalance(wallet),
  ]);
  console.log('After x402 settlement and idle-deposit sweep:');
  console.log(`  wallet USDC: ${formatUsdc(walletBalance)} USDC`);
  console.log(`  dvUSDC shares: ${dvUsdcBalance}`);
}

async function waitForFinalIdleSweepState(): Promise<void> {
  if (lastIdleDepositFloor === undefined) return;

  const deadline = Date.now() + BALANCE_TIMEOUT_MS;
  let balance = await divigent.usdcBalance(wallet);

  while (balance > lastIdleDepositFloor && Date.now() < deadline) {
    await sleep(BALANCE_POLL_MS);
    balance = await divigent.usdcBalance(wallet);
  }
}

type MerchantEndpoint = {
  paidUrl: string;
  close: () => Promise<void>;
};

async function startLocalMerchantEndpoint(params: {
  asset: EvmAddress;
  amount: bigint;
  facilitatorUrl: string;
  payTo: EvmAddress;
  port: number;
}): Promise<MerchantEndpoint> {
  const app = express();
  app.use(express.json());

  const resourceServer = new x402ResourceServer(
    new HTTPFacilitatorClient({ url: params.facilitatorUrl }),
  )
    .register(X402_NETWORK, new ExactEvmServer())
    .onAfterSettle(async (ctx) => {
      console.log('Merchant settled x402 payment:');
      console.log(`  tx: ${ctx.result.transaction}`);
      console.log(`  payer: ${ctx.result.payer ?? 'unknown'}`);
    });

  app.use(paymentMiddleware(
    {
      [`GET ${PAID_PATH}`]: {
        accepts: {
          scheme: 'exact',
          network: X402_NETWORK,
          payTo: params.payTo,
          price: {
            amount: params.amount.toString(),
            asset: params.asset,
            extra: {
              assetTransferMethod: 'permit2',
            },
          },
          maxTimeoutSeconds: 300,
        },
        description: 'Divigent x402 Base Sepolia demo',
        mimeType: 'application/json',
        unpaidResponseBody: () => ({
          contentType: 'application/json',
          body: { error: 'x402 payment required' },
        }),
        settlementFailedResponseBody: (_ctx, settle) => ({
          contentType: 'application/json',
          body: {
            error: 'x402 settlement failed',
            reason: settle.errorReason,
            message: settle.errorMessage,
          },
        }),
      },
    },
    resourceServer,
    {
      appName: 'Divigent x402 demo',
      testnet: true,
    },
  ));

  app.get(PAID_PATH, (_req, res) => {
    res.json({
      ok: true,
      message: 'Paid with x402 after Divigent made wallet USDC liquid.',
      network: X402_NETWORK,
      asset: params.asset,
      amount: params.amount.toString(),
    });
  });

  const server = await listen(app, params.port);

  const address = server.address();
  if (typeof address !== 'object' || address === null) {
    throw new Error('Unable to read local x402 merchant address');
  }

  return {
    paidUrl: `http://127.0.0.1:${address.port}${PAID_PATH}`,
    close: () => closeServer(server),
  };
}

async function waitForUsdcAllowanceAtLeast(spender: `0x${string}`, amount: bigint): Promise<void> {
  const deadline = Date.now() + ALLOWANCE_TIMEOUT_MS;
  let allowance = await readUsdcAllowance(spender);

  while (allowance < amount && Date.now() < deadline) {
    await sleep(ALLOWANCE_POLL_MS);
    allowance = await readUsdcAllowance(spender);
  }

  if (allowance < amount) {
    throw new Error(
      `USDC allowance for ${spender} is ${formatUsdc(allowance)}; expected at least ${formatUsdc(amount)} USDC`,
    );
  }
}

function readUsdcAllowance(spender: `0x${string}`): Promise<bigint> {
  return publicClient.readContract({
    address: x402Asset,
    abi: usdcAbi,
    functionName: 'allowance',
    args: [wallet, spender],
  });
}

async function waitForUsdcBalanceAtMost(maximum: bigint): Promise<void> {
  const deadline = Date.now() + BALANCE_TIMEOUT_MS;
  let balance = await divigent.usdcBalance(wallet);

  while (balance > maximum && Date.now() < deadline) {
    await sleep(BALANCE_POLL_MS);
    balance = await divigent.usdcBalance(wallet);
  }

  if (balance > maximum) {
    throw new Error(
      `Wallet USDC balance is still ${formatUsdc(balance)}; expected at most ${formatUsdc(maximum)} after deposit`,
    );
  }
}

async function waitForUsdcBalanceAtLeast(minimum: bigint): Promise<void> {
  const deadline = Date.now() + BALANCE_TIMEOUT_MS;
  let balance = await divigent.usdcBalance(wallet);

  while (balance < minimum && Date.now() < deadline) {
    await sleep(BALANCE_POLL_MS);
    balance = await divigent.usdcBalance(wallet);
  }

  if (balance < minimum) {
    throw new Error(
      `Wallet USDC balance is still ${formatUsdc(balance)}; expected at least ${formatUsdc(minimum)} after withdraw`,
    );
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function listen(app: Express, port: number): Promise<Server> {
  const server = app.listen(port, '127.0.0.1');
  await new Promise<void>((resolve, reject) => {
    server.once('listening', resolve);
    server.once('error', reject);
  });
  return server;
}

async function closeServer(server: Server): Promise<void> {
  if (!server.listening) return;
  await new Promise<void>((resolve, reject) => {
    server.close((err) => {
      if (err) reject(err);
      else resolve();
    });
  });
}

function logSettlementHeader(response: Response): void {
  const header = response.headers.get('PAYMENT-RESPONSE');
  if (!header) {
    console.log('No PAYMENT-RESPONSE header returned');
    return;
  }

  try {
    const settlement = decodePaymentResponseHeader(header) as {
      success?: boolean;
      transaction?: string;
      network?: string;
      payer?: string;
      errorReason?: string;
    };
    console.log(`x402 settlement success: ${settlement.success ? 'yes' : 'no'}`);
    if (settlement.transaction) console.log(`x402 settlement tx: ${settlement.transaction}`);
    if (settlement.network) console.log(`x402 settlement network: ${settlement.network}`);
    if (settlement.payer) console.log(`x402 settlement payer: ${settlement.payer}`);
    if (settlement.errorReason) console.log(`x402 settlement error: ${settlement.errorReason}`);
  } catch (err) {
    console.log(`Unable to decode PAYMENT-RESPONSE header: ${String(err)}`);
  }
}
